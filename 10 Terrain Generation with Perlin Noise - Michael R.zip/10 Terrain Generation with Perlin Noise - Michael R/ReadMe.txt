General Notes:

This program uses Perlin Noise to generate a seemingly random but also aligned array of rectangles.
There is also motion added, which makes the generated 'terrain' pan from right to left at a certain speed.

The flag is always placed upon the highest peak, and the program constantly checks both the average height and the highest peak.

How to use:

Use LEFT and RIGHT ARROW keys to zoom in and out of the scene. This will not change how the flag orients itself.