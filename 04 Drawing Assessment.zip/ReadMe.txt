How to change the background?
D - Daytime (default)
R - Rainy weather
N - Nightime


Use the keyboard to change time of day and mouse to move the clouds.